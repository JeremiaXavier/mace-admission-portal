<?= $this->extend('layouts/admin_layout') ?>

<?= $this->section('content') ?>

<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<style>
    /* Tailwind compatibility overrides for DataTables */
    .dataTables_wrapper .dataTables_length select { 
        border: 1px solid #d1d5db; 
        border-radius: 0.375rem; 
        padding: 0.25rem 2rem 0.25rem 0.5rem; 
        background-color: white;
    }
    .dataTables_wrapper .dataTables_filter input { 
        border: 1px solid #d1d5db; 
        border-radius: 0.375rem; 
        padding: 0.25rem 0.5rem; 
        margin-left: 0.5rem; 
    }
    table.dataTable.no-footer { border-bottom: 1px solid #e5e7eb; }
    table.dataTable thead th { border-bottom: 1px solid #e5e7eb; padding: 12px 18px; }
    table.dataTable tbody td { padding: 12px 18px; }
    .dataTables_wrapper .dataTables_paginate .paginate_button.current, 
    .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
        background: #0a4275 !important;
        color: white !important;
        border: 1px solid #062c4f;
        border-radius: 4px;
    }
</style>

<div class="mb-6 flex justify-between items-end no-print">
    <div>
        <h2 class="text-2xl font-bold text-gray-800">Branch-wise Rank Lists</h2>
        <p class="text-sm text-gray-500 mt-1">Select a branch to view all applicants who selected it, and manually sort by Option Preference.</p>
    </div>
</div>

<div class="bg-white rounded-lg shadow-sm p-4 mb-6 border border-gray-200">
    <div class="flex flex-col sm:flex-row items-end gap-4">
        <div class="w-full sm:w-1/2 md:w-64">
            <label for="branchSelect" class="block text-sm font-bold text-nic-darkblue mb-1">Select Course / Branch</label>
            <select id="branchSelect" class="block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-nic-blue focus:border-nic-blue sm:text-sm font-medium text-gray-700">
                <option value="">-- Choose a Branch --</option>
                <?php 
                $branches = [
                    'AI' => 'Artificial Intelligence',
                    'CE' => 'Civil Engineering',
                    'CSE'=> 'Computer Science',
                    'DS' => 'Data Science',
                    'EEE'=> 'Electrical & Electronics',
                    'ECE'=> 'Electronics & Communication',
                    'ME' => 'Mechanical Engineering'
                ];
                foreach($branches as $code => $name): ?>
                    <option value="<?= $code ?>"><?= $code ?> (<?= $name ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="w-full sm:w-1/2 md:w-64">
            <label for="categorySelect" class="block text-sm font-bold text-nic-darkblue mb-1">Filter by Category</label>
            <select id="categorySelect" class="block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-nic-blue focus:border-nic-blue sm:text-sm font-medium text-gray-700">
                <option value="">All Categories</option>
                <option value="SM">SM (State Merit)</option>
                <option value="EZ">EZ (Ezhava)</option>
                <option value="MU">MU (Muslim)</option>
                <option value="BH">BH (Backward Hindu)</option>
                <option value="LA">LA (Latin Catholic & Anglo Indian)</option>
                <option value="DV">DV (Dheevara)</option>
                <option value="VK">VK (Viswakarma)</option>
                <option value="BX">BX (Backward Christian)</option>
                <option value="KU">KU (Kudumbi)</option>
                <option value="KN">KN (Kusavan)</option>
                <option value="SC">SC (Scheduled Caste)</option>
                <option value="ST">ST (Scheduled Tribe)</option>
            </select>
        </div>
    </div>
</div>

<!-- Data Table Container -->
<div class="bg-white rounded-lg shadow-sm border border-gray-200 p-4" id="tableContainer" style="display:none;">
    <div class="overflow-x-auto">
        <table id="rankTable" class="min-w-full divide-y divide-gray-200 stripe hover" style="width:100%">
            <thead class="bg-gray-50">
                <tr>
                    <th class="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">KEAM Rank</th>
                    <th class="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Roll No</th>
                    <th class="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Name & Mobile</th>
                    <th class="text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Cat.</th>
                    <th class="text-left text-xs font-semibold text-nic-darkblue uppercase tracking-wider">Option Pref</th>
                    <th class="text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Action</th>
                </tr>
            </thead>
            <tbody id="rankTbody" class="bg-white divide-y divide-gray-200 text-sm">
                <!-- Populated by DataTables -->
            </tbody>
        </table>
    </div>
</div>

<!-- jQuery and DataTables Scripts -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    let dataTable = null;

    function fetchRankListData() {
        const branch = document.getElementById('branchSelect').value;
        const category = document.getElementById('categorySelect').value;
        
        if (!branch) {
            document.getElementById('tableContainer').style.display = 'none';
            return;
        }

        document.getElementById('tableContainer').style.display = 'block';
        const url = `<?= base_url('admin/ranklist/fetch') ?>?branch=${encodeURIComponent(branch)}&category=${encodeURIComponent(category)}`;

        if (dataTable) {
            dataTable.destroy(); // Destroy previous instance
            document.getElementById('rankTbody').innerHTML = ''; // Clear DOM
        }

        dataTable = $('#rankTable').DataTable({
            ajax: {
                url: url,
                dataSrc: 'applicants'
            },
            columns: [
                { 
                    data: 'entrance_rank', 
                    render: function(data) { return `<strong class="text-gray-900">${data}</strong>`; } 
                },
                { 
                    data: 'entrance_roll_no',
                    render: function(data) { return `<span class="font-bold text-nic-darkblue">${data}</span>`; }
                },
                { 
                    data: null,
                    render: function(data, type, row) { 
                        return `
                        <div class="font-bold text-gray-800">${row.full_name}</div>
                        <div class="text-gray-500 text-xs mt-0.5 flex items-center">
                            <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                            ${row.mobile_no}
                        </div>`;
                    }
                },
                { 
                    data: 'eligible_category',
                    render: function(data) {
                        return `<span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 border border-gray-200">${data}</span>`;
                    }
                },
                { 
                    data: 'pref_no', 
                    render: function(data) { 
                        return `<span class="bg-nic-lightblue text-nic-darkblue px-2.5 py-1 rounded text-sm font-extrabold border border-blue-200">Option ${data}</span>`;
                    }
                },
                {
                    data: null,
                    className: "text-right",
                    render: function(data, type, row) {
                        if (row.allotted_course) {
                            if (row.allotted_course === branch) {
                                return `<span class="bg-green-100 text-green-800 px-3 py-1.5 rounded text-xs font-bold border border-green-200 shadow-sm"><svg class="inline w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>Admitted</span>`;
                            } else {
                                return `<span class="bg-gray-100 text-gray-600 px-3 py-1.5 rounded text-xs font-bold border border-gray-300">Admitted to ${row.allotted_course}</span>`;
                            }
                        } else {
                            return `<button onclick="admitStudent(${row.id}, '${branch}')" class="bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded text-xs font-bold transition shadow-sm">Admit</button>`;
                        }
                    }
                }
            ],
            order: [[0, 'asc']], // Default sort: column 0 (KEAM Rank) Ascending
            pageLength: 50,
            language: {
                emptyTable: "No applicants found for this branch and category."
            }
        });
    }

    document.getElementById('branchSelect').addEventListener('change', fetchRankListData);
    document.getElementById('categorySelect').addEventListener('change', fetchRankListData);

    function admitStudent(id, branch) {
        if(confirm(`Are you sure you want to ADMIT this student to ${branch}?`)) {
            $.ajax({
                url: '<?= base_url('admin/ranklist/admit') ?>',
                type: 'POST',
                data: {
                    id: id,
                    branch: branch,
                    <?= csrf_token() ?>: '<?= csrf_hash() ?>'
                },
                success: function(response) {
                    if(response.success) {
                        dataTable.ajax.reload(null, false); // Reload table without resetting pagination
                    } else {
                        alert("Error admitting student.");
                    }
                }
            });
        }
    }
</script>

<?= $this->endSection() ?>
